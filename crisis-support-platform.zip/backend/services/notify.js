// backend/services/notify.js
require('dotenv').config();
const sgMail = require('@sendgrid/mail');
let twClient = null;
try { twClient = require('twilio')(process.env.TWILIO_SID, process.env.TWILIO_AUTH); } catch(e) { console.warn('twilio not configured'); }

if (process.env.SENDGRID_API_KEY) sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const STAFF_EMAIL = process.env.STAFF_EMAIL || '';
const STAFF_PHONE = process.env.STAFF_PHONE || '';

async function notifyStaff(request) {
  const subject = `[CRISIS] ${request.urgency.toUpperCase()} - Request #${request.id}`;
  const text = `New crisis request:\n\nID: ${request.id}\nName: ${request.name}\nContact: ${request.contact}\nUrgency: ${request.urgency}\nMessage: ${request.message}\nCreated: ${request.createdAt}`;

  // Send email via SendGrid
  if (process.env.SENDGRID_API_KEY && STAFF_EMAIL) {
    const msg = {
      to: STAFF_EMAIL.split(',').map(s => s.trim()),
      from: process.env.SENDGRID_FROM || STAFF_EMAIL.split(',')[0].trim(),
      subject,
      text,
    };
    try { await sgMail.send(msg); } catch (err) { console.error('sendgrid error', err); }
  }

  // Send SMS via Twilio
  if (twClient && STAFF_PHONE) {
    const phones = STAFF_PHONE.split(',').map(s => s.trim());
    for (const p of phones) {
      try { await twClient.messages.create({ body: `${subject} - ${request.contact}`, to: p, from: process.env.TWILIO_FROM }); } catch (err) { console.error('twilio error', err); }
    }
  }

  // Fallback: log to console (or write to file / DB)
  console.log('notify: ', subject);
}

module.exports = { notifyStaff };