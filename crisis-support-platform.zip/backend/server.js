// backend/server.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { notifyStaff } = require('./services/notify');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const limiter = rateLimit({ windowMs: 60*1000, max: 30 });
app.use(limiter);

const requests = [];
let idCounter = 1;

app.post('/api/requests', async (req, res) => {
  try {
    const { name, contact, urgency, message } = req.body;
    if (!contact) return res.status(400).json({ error: 'contact_required' });

    const item = {
      id: idCounter++,
      name: name || 'Anonymous',
      contact,
      urgency: urgency || 'normal',
      message: message || '',
      status: 'new',
      createdAt: new Date().toISOString(),
    };
    requests.push(item);

    // notify staff asynchronously
    notifyStaff(item).catch(err => console.error('notify error', err));

    res.json({ ok: true, id: item.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server_error' });
  }
});

// Simple admin auth via header token (replace with real auth in production)
function requireAdmin(req, res, next) {
  const token = req.header('x-admin-token');
  if (!process.env.ADMIN_TOKEN || token !== process.env.ADMIN_TOKEN) return res.status(401).json({ error: 'unauthorized' });
  next();
}

app.get('/api/admin/requests', requireAdmin, (req, res) => {
  res.json({ requests });
});

app.post('/api/admin/requests/:id/status', requireAdmin, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const r = requests.find(x => x.id === id);
  if (!r) return res.status(404).json({ error: 'not_found' });
  r.status = req.body.status || r.status;
  r.handledAt = new Date().toISOString();
  res.json({ ok: true, request: r });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));