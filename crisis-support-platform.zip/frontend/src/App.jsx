import React from 'react';
import CrisisConnectApp from './CrisisConnectApp';
import AdminDashboard from './AdminDashboard';

export default function App() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('admin') === '1') return <AdminDashboard />;
  return <CrisisConnectApp />;
}