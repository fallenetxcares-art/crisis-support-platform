import React, { useState } from 'react';

export default function CrisisConnectApp() {
  const [form, setForm] = useState({ name: '', contact: '', urgency: 'normal', message: '' });
  const [status, setStatus] = useState({ state: 'idle' });

  async function submit(e) {
    e.preventDefault();
    setStatus({ state: 'sending' });
    try {
      const res = await fetch((process.env.REACT_APP_API_BASE || '') + '/api/requests', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(form)
      });
      const j = await res.json();
      if (j.ok) setStatus({ state: 'sent', id: j.id }); else setStatus({ state: 'error', error: j.error });
    } catch (err) {
      setStatus({ state: 'error', error: 'network' });
    }
  }

  return (
    <div className="min-h-screen bg-neutral-900 text-neutral-100 p-6 flex items-center justify-center">
      <div className="w-full max-w-lg bg-neutral-800 p-6 rounded-2xl shadow-xl">
        <h1 className="text-3xl font-extrabold mb-2">Crisis Connect</h1>
        <p className="text-neutral-300 mb-4">If you are in immediate danger call <strong>911</strong> or reach the crisis hotline at <strong>988</strong>.</p>

        {status.state === 'sent' ? (
          <div className="p-4 bg-green-50 text-green-900 rounded">Request submitted. ID: {status.id}. Our team will contact you shortly.</div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <label className="block"><div className="text-sm mb-1">Your name</div><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="w-full p-3 rounded bg-neutral-700 border" placeholder="Name (optional)"/></label>
            <label className="block"><div className="text-sm mb-1">Phone or Email</div><input required value={form.contact} onChange={e=>setForm({...form,contact:e.target.value})} className="w-full p-3 rounded bg-neutral-700 border" placeholder="How can we reach you?"/></label>
            <label className="block"><div className="text-sm mb-1">Urgency</div><select value={form.urgency} onChange={e=>setForm({...form,urgency:e.target.value})} className="w-full p-3 rounded bg-neutral-700 border"><option value="normal">Normal</option><option value="urgent">Urgent</option><option value="immediate">Immediate</option></select></label>
            <label className="block"><div className="text-sm mb-1">Message (optional)</div><textarea value={form.message} onChange={e=>setForm({...form,message:e.target.value})} className="w-full p-3 rounded bg-neutral-700 border" placeholder="Tell us what you need"></textarea></label>
            <div className="flex justify-between items-center">
              <button type="submit" className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500">Send</button>
              {status.state === 'sending' && <div className="text-sm text-neutral-400">Sending...</div>}
              {status.state === 'error' && <div className="text-sm text-yellow-300">Error: {status.error}</div>}
            </div>
          </form>
        )}

      </div>
    </div>
  );
}