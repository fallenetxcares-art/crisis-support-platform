import React, { useEffect, useState } from 'react';

export default function AdminDashboard(){
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load(){
    setLoading(true);
    const res = await fetch((process.env.REACT_APP_API_BASE||'') + '/api/admin/requests', { headers: { 'x-admin-token': process.env.REACT_APP_ADMIN_TOKEN || '' } });
    const j = await res.json();
    setRequests(j.requests || []);
    setLoading(false);
  }

  useEffect(()=>{ load(); const id = setInterval(load, 10000); return ()=>clearInterval(id); }, []);

  async function updateStatus(id, status){
    await fetch((process.env.REACT_APP_API_BASE||'') + `/api/admin/requests/${id}/status`, { method:'POST', headers:{'content-type':'application/json','x-admin-token': process.env.REACT_APP_ADMIN_TOKEN||''}, body: JSON.stringify({ status }) });
    load();
  }

  if (loading) return <div className="p-6">Loading...</div>;
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Agency Dashboard</h1>
      <table className="w-full border-collapse">
        <thead><tr><th>ID</th><th>Name</th><th>Contact</th><th>Urgency</th><th>Message</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {requests.map(r=> (
            <tr key={r.id} className="border-t"><td>{r.id}</td><td>{r.name}</td><td>{r.contact}</td><td>{r.urgency}</td><td>{r.message}</td><td>{r.status}</td>
              <td><button onClick={()=>updateStatus(r.id,'assigned')} className="mr-2">Assign</button><button onClick={()=>updateStatus(r.id,'closed')}>Close</button></td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}