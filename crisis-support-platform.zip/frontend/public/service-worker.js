// A minimal service worker for offline support -- replace with Workbox for production
const CACHE_NAME = 'crisis-cache-v1';
const OFFLINE_URL = '/index.html';
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll([OFFLINE_URL])));
});
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request).then(res => res || caches.match(OFFLINE_URL))));
});