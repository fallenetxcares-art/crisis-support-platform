# Crisis Support Platform

Quick-start:

1. Backend:
   - `cd backend`
   - copy `.env.example` to `.env` and fill values
   - `npm install`
   - `npm run dev` (or `npm start`)

2. Frontend:
   - `cd frontend`
   - `npm install`
   - set `REACT_APP_API_BASE` in `.env` or in your environment
   - `npm start`

3. Admin:
   - open `http://localhost:3000/?admin=1` and ensure `REACT_APP_ADMIN_TOKEN` matches `ADMIN_TOKEN` in backend env.

Security & compliance: see notes in the project document. Do not use this starter in production without audit.